use HospitalSysmexDB2;

-- 1 How many people have been referred for surgery?
select count(*) as SurgeryReferees
from reference2;

-- 2 What is the average time taken to see a Surgeon by Department?

Select depName,Avg(DateDiff(FSA,refDate))as AvgTime from reference2 as r
join Surgeonss on  surgeonss.empID = r.empID
join Department on  Department.depID = surgeonss.depID
group by depName;

-- 3 Who has each Surgeon had on their list and how long have they been waiting or did they wait?
select concat(surgeonFirstName," ",surgeonLastName) as 'surgeonName',datediff(FSA,refDate) as PatientWaitingdays from reference2
join patient on patient.patientID = reference2.patientID
join surgeonss on surgeonss.empID = reference2.empID
group by surgeonName;

-- 4 Assuming that all patients under 18 need to be seen by Paediatric Surgery, are there any patients who need to be reassigned?

select dob,gender,concat(patientFirstName," ",patientLastName) as 'PatientName' from Patient
join Reference2 on reference2.patientID = patient.patientID
join Surgeonss on Reference2.empID = surgeonss.empID
where dob>'2000' and Surgeonss.depID <> 5
group by PatientName;

-- 5 What percentage of patient were seen within the target of 80 days by department?

select DepName,datediff(FSA,WLD)*80/100 as percentage from Reference2 
inner join surgeonss on Surgeonss.empID = Reference2.empID
inner join department on department.depID = surgeonss.depID
group by DepName


